# -*- coding: utf-8 -*-
"""
Created on Wed Mar 21 12:22:09 2018

@author: Rakesh
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Feb 26 14:12:28 2018

@author: Naveen
"""

import pandas as pd
import numpy as np
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
import operator
from sklearn.externals import joblib
import  matplotlib.pyplot  as plt
from sklearn.cluster import KMeans
from scipy.spatial.distance import cdist
from sklearn.metrics import silhouette_samples, silhouette_score
import matplotlib.cm as cm



def read_data(file_path,file_format='csv',delimiter=None,sheet_name="Sheet1",encodig='utf-8'):
    df=None
    try:
        if file_format=="excel":
            df= pd.ExcelFile(file_path)
            df = df.parse(sheet_name)
        elif file_format=="csv":
            df= pd.read_csv(file_path,sep=delimiter,encodig='utf-8')

        elif file_format=="txt":
            df=pd.read_csv(file_path,sep=delimiter,encodig='utf-8')
            
        else:
            print("File format not supported")
         
    except: 
         print("File format not supported")
    
    return df

def treating_categorical_varibale(df):
    df_with_dummies=None
    try:
     categorical_variables = list(df.dtypes[df.dtypes == "object"].index)
     df_with_dummies=pd.concat([pd.get_dummies(df[cl],prefix=cl) for cl in categorical_variables],axis=1)
    except:
        print("File format not supported")
    return df_with_dummies



    
    
    

import scipy.stats as stats


df_file=pd.ExcelFile('C:/Users/Rakesh/Documents/Siemens/APC SHARE.ja.en.XLSX')
     
df_file=df_file.parse('All')
df_file=df_file[df_file['System status']!='Booking']
dependenet_varible=df_file['System status']
dict_unique_categoris_names={}
for cl in df_file.columns:
    dict_unique_categoris_names[cl]=[list(pd.unique(df_file[cl]))]
df_combines_cl_nm=pd.DataFrame(dict_unique_categoris_names).transpose()
df_combines_cl_nm.columns=['Variables_sub_name']
df_combines_cl_nm['Variables']=df_combines_cl_nm.index
df_combines_cl_nm['Count']=df_combines_cl_nm['Variables_sub_name'].apply(lambda x:len(x))
df_combines_cl_nm.index=range(0,df_combines_cl_nm.shape[0])
dtyes_data=pd.DataFrame(df_file.dtypes)
dtyes_data.columns=['Object_type']
dtyes_data['Variables']=dtyes_data.index
dtyes_data.index=range(0,dtyes_data.shape[0])
details_matrix=pd.merge(df_combines_cl_nm,dtyes_data,on="Variables",how='inner')


df_file['Oppty System Department']
iv='Oppty System Department'
dv='System status'
def fn_overall_predictive_power(iv,dv):
    inner_df=pd.DataFrame(df_file[[iv,dv]].groupby([iv])[dv].value_counts())
    inner_df.reset_index()
    

win_loss =df_file['System status']          
country = df_file['End User Account Country']
unique_win_loss=list(pd.unique(df_file['System status']))
unique_country=list(pd.unique(df_file['End User Account Country']))

dict_win_los=dict(zip(unique_win_loss,range(len(unique_win_loss))))
dict_unique_country=dict(zip(unique_country,range(len(unique_country))))

df_file['System status'] =df_file['System status'].map(dict_win_los)        
df_file['End User Account Country'] = df_file['End User Account Country'].map(dict_unique_country)  


'''
dm_fv=details_matrix[(details_matrix['Object_type']=='object')&(details_matrix['Count']<100)&(details_matrix['Count']>25)]
for clm in dm_fv.Variables[0:3]:
    df_file["System_status_T"] = df_file["System status"].map({0:'Won',1:'Lost'})
    df_contribution=pd.crosstab(df_file[clm],df_file["System_status_T"])
    df_contribution['Sum']=df_contribution.apply(sum,axis=1)
    for cl in df_contribution.columns:
        if cl!='Sum':
            df_contribution[cl+"_pc"]= df_contribution[cl].astype(float)/df_contribution['Sum']
    X=df_contribution[[cl for cl in df_contribution.columns if '_pc' in cl]]
    #X=df_contribution[['Lost','Won']]
    km=KMeans(5,n_jobs=-1)
    km.fit(X)
    df_contribution['Clusters']= km.labels_
    df_contribution.sort_values('Won_pc',ascending=False)
    df_contribution.groupby(['Clusters'])['Sum'].sum()
    
'''
def categorical_transformation(df_file,dep_col):
    dm_fv=pd.DataFrame(df_file.dtypes=='object')
    dm_fv = dm_fv[dm_fv[0]==True]
    dm_fv = dm_fv.index
    
    for clm in dm_fv:
        print(clm)
        df_contribution=pd.crosstab(df_file[clm],df_file[dep_col])
        df_contribution['Sum']=df_contribution.apply(sum,axis=1)
        for cl in df_contribution.columns:
            if cl!='Sum':
                df_contribution[cl+"_pc"]= df_contribution[cl].astype(float)/df_contribution['Sum']
        X=df_contribution[[cl for cl in df_contribution.columns if '_pc' in cl]]
        if df_file[dep_col].unique().shape[0]<X.shape[0]:
            n_cluster=int(round(np.sqrt(X.shape[0])))
            km=KMeans(n_cluster,n_jobs=-1)
            km.fit(np.array(X))
            df_contribution['Clusters']= km.labels_
            df_contribution['Clusters']=df_contribution['Clusters'].astype(str)+"__"+clm
            replace_cat=dict(zip(df_contribution.index,df_contribution.Clusters))
    
            #df_contribution.sort_values('Won_pc',ascending=False)
            #df_contribution.groupby(['Clusters'])['Won_pc'].mean()
            #df_contribution.groupby(['Clusters'])['Sum'].sum()
    
    df_file[clm]=df_file[clm].map(replace_cat)
    return df_file

final_df = categorical_transformation(dff,dep_column)

categorical_transformation()



def fn_best_cluster(X):
    
    distortions = []
    K = range(1,len(X))
    for k in range(1,10):
        km = KMeans(n_clusters=k,n_jobs=-1).fit(X)
        km.fit(X)
        err=sum(np.min(cdist(X, km.cluster_centers_, 'euclidean'), axis=1)) / X.shape[0]
        distortions.append(err)
    
    
    
    range_n_clusters = [2, 3, 4, 5, 6]
    for n_clusters in range_n_clusters:
        
        clusterer = KMeans(n_clusters=n_clusters, random_state=10)
        cluster_labels = clusterer.fit_predict(X)
        silhouette_avg = silhouette_score(X, cluster_labels)
        print("For n_clusters =", n_clusters,"The average silhouette_score is :", silhouette_avg)
        
        
plt.plot(range(1,len(distortions)+1), distortions, 'bx-')
plt.xlabel('k')
plt.ylabel('Distortion')
plt.title('The Elbow Method showing the optimal k')
plt.show()
        
        
        
        '''
        sample_silhouette_values = silhouette_samples(X, cluster_labels)
        
        y_lower = 10
        for i in range(n_clusters):
            # Aggregate the silhouette scores for samples belonging to
            # cluster i, and sort them
            ith_cluster_silhouette_values = \
                sample_silhouette_values[cluster_labels == i]
    
            ith_cluster_silhouette_values.sort()
    
            size_cluster_i = ith_cluster_silhouette_values.shape[0]
            y_upper = y_lower + size_cluster_i
    
            color = cm.spectral(float(i) / n_clusters)
            ax1.fill_betweenx(np.arange(y_lower, y_upper),
                              0, ith_cluster_silhouette_values,
                              facecolor=color, edgecolor=color, alpha=0.7)
    
            # Label the silhouette plots with their cluster numbers at the middle
            ax1.text(-0.05, y_lower + 0.5 * size_cluster_i, str(i))
            plt.show()
    
        '''
# Plot the elbow
plt.plot(range(1,len(distortions)+1), distortions, 'bx-')
plt.xlabel('k')
plt.ylabel('Distortion')
plt.title('The Elbow Method showing the optimal k')
plt.show()

distortions


error_list=[]
for ind,val in enumerate(distortions):
    error_list.append((distortions[ind]-distortions[ind+1]))
    

    
    




cluster_names=[[val] for val in range(1,len(distortions)+1)]
distortions=[val[0] for val in distortions]

from sklearn.linear_model import LinearRegression

model=LinearRegression()
model.fit(cluster_names,distortions)
diabetes_y_pred = model.predict(cluster_names)


def r_input(x):
    return (x in range(100000,999999))
def post_code(a):
    #a_len = len(a)       
    #b_len = len(list(set(a[::2]))+list(set(a[1::2])))

    c_len = len(set(a[::2][:2]))+len(set(a[::2][1:]))
    d_len = len(set(a[1::2][:2]))+len(set(a[1::2][1:]))
    try:
        print(((c_len >= 3 and d_len == 4) or (c_len ==4 and d_len>=3)) and r_input(int(s)))    
    except:
        print False
        
s = raw_input()
a=str(s)
post_code(a)



a = pd.DataFrame({'A':[0,1,0,1,0],'B':[True, True, False, False, False]})






