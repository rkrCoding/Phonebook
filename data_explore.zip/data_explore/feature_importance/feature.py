def fn_variable_importance_with_RF(X_train, y_train, p_type):
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.ensemble import RandomForestRegressor
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd

    if (p_type == 1):
        clf = RandomForestClassifier(random_state=0)
    elif (p_type == 2):
        clf = RandomForestRegressor(random_state=1)
    else:
        print('------------------------------------------------------------')
        print('Invalid Problem Type ..... Errrrrror !!!! ')
        print('------------------------------------------------------------')
        return
    clf.fit(X_train, y_train)

    importances = clf.feature_importances_
    features = X_train.columns
    importance = clf.feature_importances_
    importance = pd.DataFrame(importance, index=X_train.columns,
                              columns=["Importance"])
    indices = np.argsort(importances)
    plt.close()
    plt.title('Feature Importances')
    plt.barh(range(len(indices)), importances[indices], color='b', align='center')
    plt.yticks(range(len(indices)), features[indices])
    plt.xlabel('Relative Importance')
    plt.show()
    print('------------------------------------------------------------')
    print(importance.sort_values(['Importance'], ascending=False))
    print('------------------------------------------------------------')
    print('There are {} attributes.'.format(len(importance)))
    print('------------------------------------------------------------')
    n = int(input("Select top n attributes , Please enter the value of n : "))
    print('------------------------------------------------------------')
    return importance.index[0:n]


def cat_cont(dff, columns):
    for i in columns:
        if dff[i].dtype == 'O':
            dff[i] = dff[i].astype('category')
            dff[i] = dff[i].cat.codes

    return dff


def variable_importance(dff, ind_col, dep_column, p_type):
    print('------------------------------------------------------------')
    ch = int(
        input("How would you like to choose your important variable : \n1.Manually \n2.ML Algorithms\nYour Choice:"))
    print('------------------------------------------------------------')
    dff_ind_col = cat_cont(dff, ind_col.columns)
    dff_dep_col = cat_cont(dff, [dep_column])[dep_column]
    dff_ind_col = dff_ind_col.drop(dep_column, axis=1)
    if ch == 1:
        for i in list(enumerate(dff_ind_col.columns)):
            print(i)
        print('------------------------------------------------------------')
        imp_col = input("Enter the Column Number Separated by ' ,  ' \nInput:")
        print('------------------------------------------------------------')
        imp_col = imp_col.split(',')
        imp_col = list(map(int, imp_col))
        df_imp = dff.columns[imp_col]

    elif ch == 2:
        df_imp = fn_variable_importance_with_RF(dff_ind_col, dff_dep_col, p_type)

    return df_imp

