def choose_file():
    import tkinter
    from tkinter.filedialog import askopenfilename
    root = tkinter.Tk()
    # root.withdraw()
    root.update()
    filename = askopenfilename()
    root.destroy()
    return filename

def choose_sheet(sheets):
    print('------------------------------------------')
    print("The file has the following sheets : ")
    for sheet in list(enumerate(df.sheet_names)):
        print(sheet)
    print('------------------------------------------')
    sheet_num = input("Please select the Sheet Number to Open : ")

    print(sheet_num)
    sheet_name = sheets[int(sheet_num)]
    print(sheet_name)
    return sheet_name

def read_dataset():
    import pandas as pd
    global df
    print('------------------------------------------')
    print('Please select the file to open')
    print('------------------------------------------')

    file_path = choose_file()
    sheet_name = ""
    sep = " "
    file_type = file_path[file_path.rfind('.'):]
    print('------------------------------------------')
    print('File Type : ',file_type)
    print('------------------------------------------')
    if file_type == ".csv":
        df = pd.read_csv(file_path)
    elif file_type == ".xlsx":
        #print("File Type : ",file_type)
        df = pd.ExcelFile(file_path)

        sheets = df.sheet_names
        sheet_name = sheets[0]
        if len(sheets) > 1:
            sheet_name = choose_sheet(sheets)

        df =df.parse(sheet_name)
        #print(df.head())
        #print("Exiting")
    elif file_type == ".zip":
        import zipfile
        archive = zipfile.ZipFile('T.zip', 'r')
        df = archive.read('train.csv')
    elif file_type == ".txt":
        df = pd.read_csv(file_path, sep=sep)
    elif file_type == ".json":
        df = pd.read_json(file_path)
    elif file_type == ".h5":
        df = pd.read_hdf(file_path)
    else:
        print('------------------------------------------')
        return("File Type Not supported")
    print('-------------------Sample Data ---------------')
    print(df.head())

    return df