def var_identify(df):
    #print("r the Dependent Column from the below list :")
    print('------------------------------------------')
    for i in list(enumerate(df)):
        print(i)
    print('------------------------------------------')
    dependent = input("Choose the Column to predict from the above list :")
    dep_col = df.columns[int(dependent)]
    dep_col_type = df[dep_col].dtype
    independent_cols = df.drop(dep_col,axis=1)
    return dep_col,dep_col_type,independent_cols


