import sys
sys.path.append("C:/Users/Rakesh/Desktop/")

import numpy as np
import pandas as pd
import data_explore.read_data.data as rd
import data_explore.var_identify.identify as vi
from data_explore.treat_missing.impute_mising import impute
from data_explore.feature_importance.feature import variable_importance,cat_cont
from data_explore.fn_cat_transformation import transformation
from data_explore.best_model.best_model import best_model
from data_explore.text_classification.classify_text import classify_text
from data_explore.analysis.univariate import uni_visualize
from data_explore.analysis.bivariate import bi_visualize




df = rd.read_dataset()
#print(df.describe())
dep_column,col_type,ind_col = vi.var_identify(df)
print('------------------------------------------------------------')
print("Dependent Column Selected = ",dep_column,",Type = ",col_type)
print('------------------------------------------------------------')
#print("Independt Column",ind_col.columns)
#visualize(df[dep_column],0,1)
#df['Bed_Size'] = df['Bed_Size'].replace(9999,np.nan)
print('------------------------------------------------------------')
p_type = int(input('Select the type of problem : \n1.Classification \n2.Regression\n3.Text Classification\nYour Choice:'))
print('------------------------------------------------------------')

if p_type==3:
    classify_text(df)
else:   
    
    df = impute(df)
    dff = df.copy()
    
    #uni_visualize(dff,1,1)
    #bi_visualize(dff)   
    
    imp_col =  variable_importance(dff,ind_col,dep_column,p_type)
    dff_temp  = dff[imp_col]
    dff_temp[dep_column]= dff[dep_column]    
    
    dff_temp1 = transformation.categorical_transformation(dff_temp,dep_column)
    y = dff_temp1[dep_column].values
    if type(y[0])==str:
        y= cat_cont(dff_temp1,[dep_column])[dep_column].values
    dff_temp1.drop(dep_column,axis=1,inplace=True)
    dff_temp1 = pd.get_dummies(dff_temp1)
    
    X = dff_temp1.values
    
    
    b_m = best_model(X,y,p_type)
    b_m = dict(b_m)
    if p_type==1:
        print('------------------------------------------------------------')
        for k,v in b_m.items():
            print('{} - {} %'.format(k,v*100))
            
        print('------------------------------------------------------------')
    else:
        print('------------------------------------------------------------')
        for k,v in b_m.items():
            print('{} - {}'.format(k,v))
            
        print('------------------------------------------------------------')