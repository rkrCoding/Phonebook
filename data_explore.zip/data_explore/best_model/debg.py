# -*- coding: utf-8 -*-
"""
Created on Thu Apr  5 11:29:31 2018

@author: Rakesh
"""

a=2
b=a
c = a+b

print(a,b,c) 