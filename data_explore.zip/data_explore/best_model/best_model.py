def get_classifiers_class(n_f):
    from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.gaussian_process import GaussianProcessClassifier
    from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.neural_network import MLPClassifier
    from xgboost import XGBClassifier
    from sklearn.kernel_ridge import KernelRidge
    from sklearn.svm import SVR

    # Dictionary of Classifier
    classifiers = {'L1 logistic': LogisticRegression(),
                   'Decision Tree': DecisionTreeClassifier(max_depth=5),
                   'MLP Classifier': MLPClassifier(hidden_layer_sizes=(n_f, n_f, n_f)),
                   'XGBoost': XGBClassifier(max_depth=5),
                   'K Nearest Neighbour': KNeighborsClassifier(3),
                   # 'Linear SVC': SVC(kernel="linear"),
                   # 'Gaussian Classifier': GaussianProcessClassifier(1.0 * RBF(1.0),n_jobs =-1),
                   'Random Forest': RandomForestClassifier(),
                   'AdaBoost': AdaBoostClassifier(),
                   'Quadratic': QuadraticDiscriminantAnalysis()
                   }
    return classifiers


def get_classifiers_regress():
    from sklearn.kernel_ridge import KernelRidge
    from sklearn.svm import SVR
    from sklearn import linear_model

    classifiers = {'Linear Regression': linear_model.LinearRegression(),
                   'Ridge Regression': linear_model.Ridge(alpha=.5),
                   'Lasso Regression': linear_model.Lasso(alpha=0.1),
                   'LassoLars Regression': linear_model.LassoLars(alpha=.1),
                   # 'Bayesian Ridge Regression': linear_model.BayesianRidge(),
                   'Support Vector Regression': SVR(C=1.0, epsilon=0.2),
                   # 'Gaussian Classifier': GaussianProcessClassifier(1.0 * RBF(1.0),n_jobs =-1),
                   'Stochastic Gradient Descent': linear_model.SGDRegressor(),
                   # 'Perceptron': linear_model.Perceptron(),
                   'Kernel Ridge Regression': KernelRidge(alpha=1.0)
                   }
    return classifiers


# function to find best classier
def save_models(X_train, y_train, classifiers, rn=1):
    import os
    from sklearn.externals import joblib

    # acc_dict = {}
    model_dir = "C:/Users/Rakesh/Desktop/saved_models/" + str(rn) + "/"
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    print('------------------------------------------')
    for index, (name, classifier) in enumerate(classifiers.items()):
        print('Running : ', name)
        classifier.fit(X_train, y_train)
        joblib_file = model_dir + name + ".pkl"
        joblib.dump(classifier, joblib_file)
    print('------------------------------------------')


def restore_models(X_test, y_test, rn, p_type):
    from sklearn.externals import joblib
    import operator
    model_path = "C:/Users/Rakesh/Desktop/saved_models/" + str(rn) + "/"
    acc_dict = {}
    models = []
    import glob
    for model in glob.glob(model_path + '*.pkl'):
        models.append(model)
    if p_type == 1:
        print('------------------------------------------')
        for model in models:
            print('Retrieving:  ', model)
            model_name = model[model.rindex("\\") + 1:model.rindex('.')]
            joblib_model = joblib.load(model)
            acc_dict[model_name] = joblib_model.score(X_test, y_test)
        print('------------------------------------------')
        return sorted(acc_dict.items(), key=operator.itemgetter(1), reverse=True)

    elif p_type == 2:
        from sklearn.metrics import mean_squared_error, r2_score
        print('------------------------------------------')
        for model in models:
            print('Retrieving:  ', model)
            model_name = model[model.rindex("\\") + 1:model.rindex('.')]
            joblib_model = joblib.load(model)
            y_pred = joblib_model.predict(X_test)
            acc_dict[model_name] = r2_score(y_test, y_pred)
        print('------------------------------------------')
        return sorted(acc_dict.items(), key=operator.itemgetter(1))

    else:
        print('Invalid Type...... Errrrrrorrrr !!!')
        return



def best_model(X, y, p_type):
    mdl = ''
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=10, test_size=0.3)
    if p_type == 1:
        classifier = get_classifiers_class(X_train.shape[1])
    elif p_type == 2:
        classifier = get_classifiers_regress()
    else:
        print('Invlaid Input !!!! Errrrrrrrrrror ')
        return

    save_models(X_train, y_train, classifier, p_type)
    if p_type == 1:
        mdl = restore_models(X_test, y_test, p_type,p_type)
    elif p_type == 2:
        mdl = restore_models(X_test, y_test, p_type, p_type)
    else:
        print('Invlaid Input !!!! Errrrrrrrrrror ')
        mdl = 'Null'

    return mdl




