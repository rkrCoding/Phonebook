
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import sent_tokenize, word_tokenize
import string
from sklearn.naive_bayes import *
from sklearn.dummy import *
from sklearn.ensemble import *
from sklearn.neighbors import *
from sklearn.tree import *
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.calibration import *
from sklearn.linear_model import *
from sklearn.multiclass import *
from sklearn.svm import *
import pandas


def transform_text(txt):
    sentences = sent_tokenize(txt)
    tokens = word_tokenize(txt)
    tokens = [w.lower() for w in tokens]
    table = str.maketrans('', '', string.punctuation)
    stripped = [w.translate(table) for w in tokens]
    words = [word for word in stripped if word.isalpha()]
    stop_words = set(stopwords.words('english'))
    words = [w for w in words if not w in stop_words]
    stemmer = PorterStemmer()
    lemmatiser = WordNetLemmatizer()
    words = ' '.join(words)
    words = stemmer.stem(words)
    words = lemmatiser.lemmatize(words, pos="v")

    return words


def classify_text(df):
    from sklearn.cross_validation import train_test_split
    from sklearn.feature_extraction.text import CountVectorizer
    from sklearn.feature_extraction.text import TfidfVectorizer

    from sklearn.naive_bayes import MultinomialNB
    from sklearn.metrics import accuracy_score, precision_score, f1_score

    df.dropna(inplace=True)

    ind_col = df.columns[0]
    dep_col = df.columns[1]

    if df[dep_col].dtype == 'float64':
        df[dep_col] = df[dep_col].map(int)

    df[ind_col] = df[ind_col].apply(lambda x: transform_text(x))

    X = df[ind_col].values
    y = df[dep_col].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=5)

    classifiers = [BernoulliNB(),
                   RandomForestClassifier(n_estimators=100, n_jobs=-1),
                   AdaBoostClassifier(),
                   BaggingClassifier(),
                   ExtraTreesClassifier(),
                   GradientBoostingClassifier(),
                   DecisionTreeClassifier(),
                   CalibratedClassifierCV(),
                   DummyClassifier(),
                   PassiveAggressiveClassifier(),
                   RidgeClassifier(),
                   RidgeClassifierCV(),
                   SGDClassifier(),
                   OneVsRestClassifier(SVC(kernel='linear')),
                   OneVsRestClassifier(LogisticRegression()),
                   KNeighborsClassifier()]

    vectorizers = [
        CountVectorizer(),
        TfidfVectorizer(),
        HashingVectorizer()
    ]

    for classifier in classifiers:
        for vectorizer in vectorizers:
            string = ''
            string += classifier.__class__.__name__ + ' with ' + vectorizer.__class__.__name__

            # train
            vectorize_text = vectorizer.fit_transform(X_train)
            classifier.fit(vectorize_text, y_train)

            # score
            vectorize_text = vectorizer.transform(X_test)
            score = classifier.score(vectorize_text, y_test)
            string += '. Has score: ' + str(score)
            print('------------------------------------------------------------')
            print(string)
            print('------------------------------------------------------------')
