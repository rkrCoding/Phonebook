def bi_visualize(ind_col):
    import seaborn as sns
    import os
    import matplotlib.pyplot as plt
    analysis_type = 'bivariate'

    print('----------------------------------------------------------------')
    print('Running Bivariate Analysis')
    print('----------------------------------------------------------------')

    if not os.path.exists(os.getcwd() + '/' + analysis_type + '/'):
        os.makedirs(os.getcwd() + '/' + analysis_type + '/')

    cont_columns = []
    cat_columns = []

    for cols in ind_col:
        if ind_col[cols].dtype in ['int64', 'float64']:
            cont_columns.append(cols)
        else:
            cat_columns.append(cols)

    df_cont = ind_col[cont_columns]
    sns_plot = sns.heatmap(df_cont.corr(), annot=True, fmt=".2f")
    fig = sns_plot.get_figure()
    fig.savefig(os.getcwd() + '/' + analysis_type + '/'+'heatmap.png')


    sns_plot  = sns.pairplot(df_cont)
    sns_plot.savefig(os.getcwd() + '/' + analysis_type + '/' + 'pairplot.png')

    plt.close()
    print('----------------------------------------------------------------\n')

    print('Bivariate Analysis is avaiable at the below location')
    print(os.getcwd() + '/' + analysis_type + '/')

    print('\n----------------------------------------------------------------')
