def uni_visualize(ind_col, continuous=0, categorical=0):
    import matplotlib.pyplot as plt
    import os
    analysis_type = 'univariate'
    print('----------------------------------------------------------------')
    print('Running Univariate Analysis')
    print('----------------------------------------------------------------')
    if not os.path.exists(os.getcwd() + '/' + analysis_type + '/'):
        os.makedirs(os.getcwd() + '/' + analysis_type + '/')

    if len(ind_col.shape) > 1:
        if (continuous):

            for col in ind_col:
                if ind_col[col].dtype in ['int64', 'float64']:
                    txt = str(ind_col[col].describe())
                    txt = txt.split('\n')[:-1]
                    txt = '\n'.join(txt)

                    # ax1 = fig.add_subplot(131)
                    fig = plt.figure(figsize=(12, 5))
                    ax1 = fig.add_subplot(131)
                    ax1.text(0.2, 0.3, txt, family='fantasy', fontsize=15)

                    ax1 = fig.add_subplot(132)
                    ax1.hist(ind_col[col])
                    ax1.legend()

                    ax1 = fig.add_subplot(133)
                    ax1.boxplot(ind_col[col])

                    plt.tight_layout()
                    plt.savefig(os.getcwd() + '/' + analysis_type + '/' + col + '.png')
                    plt.close()

        if (categorical):
            for col in ind_col:
                if ind_col[col].dtype not in ['int64', 'float64']:
                    ind_col[col].value_counts().plot(kind='bar')
                    plt.legend(labels=[col])
                    plt.savefig(os.getcwd() + '/' + analysis_type + '/' + col + '.png')
                    plt.close()


    else:
        if (continuous):
            ind_col.plot(kind='hist')
            plt.close()
        if (categorical):
            ind_col.value_counts().plot(kind='bar')
            plt.savefig(os.getcwd() + '/' + analysis_type + '/' + ind_col + '.png')
            plt.close()

    print('----------------------------------------------------------------\n')

    print('Univariate Analysis is available at the below location')
    print(os.getcwd() + '/' + analysis_type + '/')

    print('\n----------------------------------------------------------------')

