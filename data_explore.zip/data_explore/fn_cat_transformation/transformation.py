def categorical_transformation(df_file, dep_col):
    import pandas as pd
    from sklearn.cluster import KMeans
    import numpy as np

    dm_fv = pd.DataFrame(df_file.dtypes == 'object')
    dm_fv = dm_fv[dm_fv[0] == True]
    dm_fv = dm_fv.index

    for clm in dm_fv:
        if clm != dep_col:
            print(clm)
            df_contribution = pd.crosstab(df_file[clm], df_file[dep_col])
            df_contribution['Sum'] = df_contribution.apply(sum, axis=1)
            for cl in df_contribution.columns:
                if cl != 'Sum':
                    df_contribution[cl + "_pc"] = df_contribution[cl].astype(float) / df_contribution['Sum']
            X = df_contribution[[cl for cl in df_contribution.columns if '_pc' in cl]]
            print(X)
            if df_file[dep_col].unique().shape[0] < X.shape[0]:
                n_cluster = int(round(np.sqrt(X.shape[0])))
                km = KMeans(n_cluster, n_jobs=-1)
                km.fit(np.array(X))
                df_contribution['Clusters'] = km.labels_
                df_contribution['Clusters'] = df_contribution['Clusters'].astype(str) + "__" + clm
                replace_cat = dict(zip(df_contribution.index, df_contribution.Clusters))

                # df_contribution.sort_values('Won_pc',ascending=False)
                # df_contribution.groupby(['Clusters'])['Won_pc'].mean()
                # df_contribution.groupby(['Clusters'])['Sum'].sum()

                df_file[clm] = df_file[clm].map(replace_cat)
    return df_file
