def impute(dframe):
    '''
    Missing value treatment

    '''

    dframe_isnull = dframe.isnull().sum().to_frame()
    dframe_isnull[1] = dframe.dtypes
    dframe_isnull.columns = ['Count', 'Type']
    dframe_isnull['Type'] = dframe_isnull['Type'].apply(lambda x: 'Category' if x == 'object' else 'Continuous')
    dframe_isnull = dframe_isnull[dframe_isnull['Count'] > 0]
    cont_column = dframe_isnull[(dframe_isnull['Type'] != 'Category')]
    cont_column = list(cont_column.index)
    cat_column = dframe_isnull[(dframe_isnull['Type'] == 'Category')]
    cat_column = list(cat_column.index)
    ch = 'y'
    flag = 0
    while (ch == 'y'):

        dframe_isnull = dframe.isnull().sum().to_frame()
        dframe_isnull[1] = dframe.dtypes
        dframe_isnull.columns = ['Count', 'Type']
        dframe_isnull['Type'] = dframe_isnull['Type'].apply(lambda x: 'Category' if x == 'object' else 'Continuous')
        if dframe_isnull[dframe_isnull['Count'] > 0].empty:
            print('------------------------------------------')
            print('There are no missing value in the dataset.')
            print('------------------------------------------')
            flag = 1
            break

        else:
            print('------------------------------------------')
            print("Below columns have missing values with count")
            print(dframe_isnull[dframe_isnull['Count'] > 0])
            print('------------------------------------------')
        ch = input("Do you want to continue with the Imputation (y/n):")

        if ch == 'n':

            print('--------------------------------------------------------')
            print('WARNING !!!! Some models will not be able to work !!!')
            print('ACTION NOT RECOMMENDED')
            print('-------------------------------------------------------')
            chh = input("Do you still  want to continue (y/n):")
            while (chh not in ['y', 'n']):
                print('-------------------------------------------------------')
                print('Please enter y / n ....... ')
                print('-------------------------------------------------------')
                chh = input("Do you still  want to continue (y/n):")
            if (chh == 'y'):
                return dframe
            elif (chh == 'n'):
                impute(dframe)

        print('------------------------------------------')
        inp = int(input(
            "1. Remove rows with missing value \n2. Remove Columns with missing Value \n3. Handle missing values\nYour Choice:"))
        if inp == 1:
            if (100 - (dframe.dropna().shape[0] / dframe.shape[0] * 100) > 75):
                print('------------------------------------------')
                print("More than 75% of data will removed........ Action not recommended !!!")
                print('------------------------------------------')
                inp_c = input("Still want to continue (y/n) ?\n Your Choice:")
                print('------------------------------------------')
                if inp_c == 'y':
                    dframe = dframe.dropna()
                    print(dframe.shape)
            else:
                dframe = dframe.dropna()

        elif inp == 2:
            print('------------------------------------------')
            inp_c = input(
                'Out of {} Columns {} will be removed .... Continue    (y/n)?\n Your Choice:'.format(dframe.shape[1],
                                                                                                     dframe.shape[1] -
                                                                                                     dframe.dropna(
                                                                                                         axis=1).shape[
                                                                                                         1]))
            print('------------------------------------------')
            if inp_c == 'y':
                dframe = dframe.dropna(axis=1)
                print(dframe.shape)
        elif inp == 3:
            # unique_type= dframe_isnull[dframe_isnull['Count'] > 0]['Type'].unique()
            # if 'Continuous' in unique_type:
            from sklearn.preprocessing import Imputer
            imputer_ob = Imputer(strategy="mean", axis=1)
            for col in dframe[cont_column]:
                dframe[col] = imputer_ob.fit_transform(dframe[col].values.reshape(1, -1))[0]
            # print(dframe[col].mean())
            # elif 'Category' in unique_type:
            for col in cat_column:
                dframe[col] = dframe[col].fillna(dframe[col].mode()[0])

            print('----------------------------------------------------------')
            print("Imputation Done")
            print('----------------------------------------------------------')

    if flag==1:
        return dframe



'''
def impute(dframe):
    

    dframe_isnull = dframe.isnull().sum().to_frame()
    dframe_isnull[1] = dframe.dtypes
    dframe_isnull.columns = ['Count', 'Type']
    dframe_isnull['Type'] = dframe_isnull['Type'].apply(lambda x: 'Category' if x == 'object' else 'Continuous')
    dframe_isnull = dframe_isnull[dframe_isnull['Count'] > 0]
    cont_column = dframe_isnull[(dframe_isnull['Type'] != 'Category')]
    cont_column = list(cont_column.index)
    cat_column = dframe_isnull[(dframe_isnull['Type'] == 'Category')]
    cat_column = list(cat_column.index)
    ch = 'y'

    while (ch == 'y'):

        dframe_isnull = dframe.isnull().sum().to_frame()
        dframe_isnull[1] = dframe.dtypes
        dframe_isnull.columns = ['Count', 'Type']
        dframe_isnull['Type'] = dframe_isnull['Type'].apply(lambda x: 'Category' if x == 'object' else 'Continuous')
        if dframe_isnull[dframe_isnull['Count'] > 0].empty:
            print('------------------------------------------')
            print('There are no missing value in the dataset.')
            print('------------------------------------------')
        else:
            print('------------------------------------------')
            print("Below columns have missing values with count")
            print(dframe_isnull[dframe_isnull['Count'] > 0])
            print('------------------------------------------')
        ch = input("Do you want to continue with the Imputation (y/n):")

        if ch == 'n':
            return dframe
        print('------------------------------------------')
        inp = int(input(
            "1. Remove rows with missing value \n2. Remove Columns with missing Value \n3. Handle missing values\nYour Choice:"))
        if inp == 1:
            if (100 - (dframe.dropna().shape[0] / dframe.shape[0] * 100) > 75):
                print('------------------------------------------')
                print("More than 75% of data will removed........ Action not recommended !!!")
                print('------------------------------------------')
                inp_c = input("Still want to continue (y/n) ?\n Your Choice:")
                print('------------------------------------------')
                if inp_c == 'y':
                    dframe = dframe.dropna()
                    print(dframe.shape)
            else:
                dframe = dframe.dropna()

        elif inp == 2:
            print('------------------------------------------')
            inp_c = input(
                'Out of {} Columns {} will be removed .... Continue    (y/n)?\n Your Choice:'.format(dframe.shape[1],
                                                                                                     dframe.shape[1] -
                                                                                                     dframe.dropna(
                                                                                                         axis=1).shape[
                                                                                                         1]))
            print('------------------------------------------')
            if inp_c == 'y':
                dframe = dframe.dropna(axis=1)
                print(dframe.shape)
        elif inp == 3:
            print('------------------------------------------')
            var = int(input("1. Handle Continuous Variable \n2. Handle Categorical\nYour Choice:"))
            if var == 1:
                print('------------------------------------------')
                md = int(input(
                    "Please input the method for continuous variables \n1. Mean \n2. Median \n3.Most Frequent \nYour Choice:"))
                print('------------------------------------------')
                from sklearn.preprocessing import Imputer
                if md == 1:
                    imputer_ob = Imputer(strategy="mean", axis=1)
                    for col in dframe[cont_column]:
                        dframe[col] = imputer_ob.fit_transform(dframe[col].values.reshape(1, -1))[0]
                        # print(dframe[col].mean())
                    print(dframe.shape)
                elif md == 2:
                    imputer_ob = Imputer(strategy="median", axis=1)
                    for col in dframe[cont_column]:
                        dframe[col] = imputer_ob.fit_transform(dframe[col].values.reshape(1, -1))[0]
                    print(dframe.shape)
                elif md == 3:
                    imputer_ob = Imputer(strategy="most_frequent", axis=1)
                    for col in dframe[cont_column]:
                        dframe[col] = imputer_ob.fit_transform(dframe[col].values.reshape(1, -1))[0]


            elif var == 2:
                print('----------------------------------------------------------')
                print("For categorical variable Imputation mode will be used.....")
                print('----------------------------------------------------------')
                # missing_column = dframe_isnull[dframe_isnull[0] > 0].index
                for col in cat_column:
                    dframe[col] = dframe[col].fillna(dframe[col].mode()[0])
'''